package com.senac.pedro.controleglp.view;

import android.app.Activity;
import android.os.Bundle;

import com.senac.pedro.controleglp.R;

public class PrincipalActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
    }
}
